# Revision history for Haskell-Chess

## 0.1.0.0  -- 2017-04-15

* First version. Released on an unsuspecting world.
