# Instructions

#### Start off the game by following the steps given [here](https://github.com/thecodesome/Haskell-Chess)

![Game](pics/1.png)

### How to move

#### Left click on the piece that you want to move
![Left click](pics/2.png)

#### Right click on the destination
![Right click](pics/3.png)

#### You will be notified about the moves in the console.
![Notifications](pics/4.png)

![Notifications](pics/5.png)
