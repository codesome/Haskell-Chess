# Chat

As it says when you start the game, just type anything and press [Enter] at any point of time, and the chat is on!

See below for an example.

![Chat](pics/6.png)
